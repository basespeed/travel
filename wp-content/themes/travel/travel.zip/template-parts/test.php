<?php
    get_header();
?>
<h1>sdaaaaaaaaa</h1>
<h1>sdaaaaaaaaa</h1>
<h1>sdaaaaaaaaa</h1>
<h1>sdaaaaaaaaa</h1>
<h1>sdaaaaaaaaa</h1>
    <input type="text" id="id">
    <input type="text" id="name">
    <button class="insert">Add</button>
    <button class="update">Update</button>
<?php
    get_footer();
?>