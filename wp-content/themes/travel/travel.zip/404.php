<?php
ob_start();
header("Location: ".home_url('/'));
exit();